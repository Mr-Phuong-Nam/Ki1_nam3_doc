#!/bin/bash
cd ../build.linux
make clean
make
cd ../test
