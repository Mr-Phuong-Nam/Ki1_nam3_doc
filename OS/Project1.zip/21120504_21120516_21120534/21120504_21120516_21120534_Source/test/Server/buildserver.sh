#!/bin/bash
rm -f server
gcc -o server server.c
./server